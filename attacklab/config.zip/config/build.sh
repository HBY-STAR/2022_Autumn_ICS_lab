#!/bin/bash
PASSWORD=123456
CTARGET='/home/diane/Downloads/target30/ctarget'
RTARGET='/home/diane/Downloads/target30/rtarget'

echo $PASSWORD | sudo -S apt-get install g++ autoconf automake libtool

cd patchelf-master
chmod +x bootstrap.sh
chmod +x configure
chmod +x tests/*.sh
./bootstrap.sh
./configure
make
make check
echo $PASSWORD | sudo -S make install

cd ../glibc-all-in-one-master
chmod +x update_list
chmod +x download
chmod +x extract
./extract debs/libc6_2.27-3ubuntu1.6_amd64.deb /tmp/test
./extract debs/libc6-dbg_2.27-3ubuntu1.6_amd64.deb /tmp/test_dbg

patchelf --set-interpreter /tmp/test/ld-2.27.so --set-rpath /tmp/test/ $CTARGET
patchelf --set-interpreter /tmp/test/ld-2.27.so --set-rpath /tmp/test/ $RTARGET
